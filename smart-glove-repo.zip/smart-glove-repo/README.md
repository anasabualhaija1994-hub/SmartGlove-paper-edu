# Two-Way Smart Glove — code and data

Code, data and figures for

> R. Altamimi and A. Abu Alhaija'a, "Interactive Learning through Assistive Technology: A Two-Way Smart Glove for Students with Communication Impairments."

The glove translates 30 calibrated hand gestures into pre-recorded speech (gesture-to-speech) and shows speech transcribed by a smartphone on a 16×2 LCD at the wrist (speech-to-text).

## Repository layout

| Path | Content |
|---|---|
| `firmware/gesture_to_speech/` | Main Arduino firmware (Arduino Pro Mini 3.3 V / 8 MHz): template matching, DFPlayer audio, Bluetooth text → LCD |
| `firmware/calibration/` | Calibration sketch that records the min/max template of one gesture (10 windows × 1,000 readings per channel, ±10 margin) |
| `android/SmartGloveSTT/` | Android app: speech recognition with `RecognizerIntent` (en-US by default) and Bluetooth (SPP) transfer to the glove |
| `data/csv/` | Trial-level data: `gesture_recognition.csv` (900 trials), `speech_recognition.csv` (90 trials per condition), `speech_test_phrases.csv`, `gesture_summary.csv` |
| `data/audio_tracks.csv` | Audio track list: word, DFPlayer track number and SD-card file of each gesture |
| `data/smart_glove_measurements.xlsx` | The same data (trials, summary, test phrases, audio tracks) as one workbook |
| `analysis/analyze.py` | Reproduces every statistic of the Results section, Table 3 and Figures 6–7 (written to `analysis/results/`) |
| `docs/figures/` | Figures 1–5, 8 and 9 of the paper; `src/make_block_diagrams.py` redraws Figures 2–4 |

## Reproducing the results

```bash
cd analysis
pip install -r requirements.txt
python analyze.py          # prints the statistics and writes results/ (figures, per-gesture table, summary.txt)
```

Expected output (abridged): gesture accuracy 97.2 % (875/900), Wilson 95 % CI 95.9–98.1 %, cluster bootstrap 95.8–98.6 %; STT exact-phrase accuracy 95.6 % (quiet) and 88.9 % (noise), Fisher p = 0.16.

## Building the firmware

Libraries: `hd44780` (Bill Perry), `DFRobotDFPlayerMini`, `MPU6050` (I2Cdevlib / Electronic Cats). Board: *Arduino Pro or Pro Mini, ATmega328P (3.3 V, 8 MHz)*.

Pins: flex sensors A0, A1, A2, A3, A6 (10 kΩ dividers); MPU-6050 and LCD backpack on I²C (A4/A5); HC-05 on the hardware serial port (9600 baud); DFPlayer Mini on D10/D11 (software serial); vibration motor (via transistor) and LED on D8.

Audio: copy the recordings to the SD card as `/mp3/NNNN.mp3`, with the track numbers listed in `data/audio_tracks.csv`.

Templates are user-specific. To calibrate your own glove, upload `firmware/calibration/calibration.ino`, open the Serial Monitor at 57600 baud, hold the gesture whenever `Move Now` appears (10 windows), and paste the printed template row into `TEMPLATES[]` with the gesture's audio-track number.

## Android app

Open `android/SmartGloveSTT` in Android Studio (compileSdk 34, minSdk 21). Before building, set the Bluetooth address of your HC-05 module in `DevicesInfo.java` and pair the module in the Android Bluetooth settings.

## Licence

MIT (see `LICENSE`).
