"""Reproduce all statistics, Table 3 and Figures 6-7 of the Two-Way Smart Glove paper.

Usage:  python analyze.py            (reads ../data/csv, writes ./results)
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

HERE = Path(__file__).resolve().parent
DATA = HERE.parent / "data" / "csv"
OUT = HERE / "results"
OUT.mkdir(exist_ok=True)

ROUNDS = 3
BOOTSTRAP_RESAMPLES = 100_000
SEED = 2026
BLUE, RED = "#2F6B9A", "#B5452F"
plt.rcParams.update({"font.family": "serif", "font.size": 9,
                     "axes.spines.top": False, "axes.spines.right": False})


def wilson(k, n):
    lo, hi = stats.binomtest(k, n).proportion_ci(method="wilson")
    return 100 * lo, 100 * hi


def round_accuracies(values, rounds=ROUNDS):
    per = len(values) // rounds
    return np.array([values[i * per:(i + 1) * per].mean() * 100 for i in range(rounds)])


lines = []
say = lambda s="": (print(s), lines.append(s))

# ------------------------------------------------------------------ gestures
g = pd.read_csv(DATA / "gesture_recognition.csv")
order = g.drop_duplicates("GestureID").sort_values("GestureID")["Gesture"].tolist()
rows = []
for name in order:
    v = g.loc[g.Gesture == name].sort_values("Trial")["Recognized"].to_numpy()
    r = round_accuracies(v)
    rows.append(dict(Gesture=name, Trials=len(v), Correct=int(v.sum()),
                     Accuracy=v.mean() * 100, SD_rounds=r.std(ddof=0),
                     Round1=r[0], Round2=r[1], Round3=r[2]))
per_gesture = pd.DataFrame(rows)
per_gesture.to_csv(OUT / "per_gesture_accuracy.csv", index=False, float_format="%.2f")

k, n = int(g.Recognized.sum()), len(g)
lo, hi = wilson(k, n)
say("GESTURE RECOGNITION")
say(f"  overall accuracy : {100 * k / n:.1f}% ({k}/{n}), Wilson 95% CI {lo:.1f}-{hi:.1f}%")
say(f"  mean of per-gesture accuracies : {per_gesture.Accuracy.mean():.1f}%")
acc_g = g.groupby("GestureID").Recognized.mean().to_numpy()
rng = np.random.default_rng(SEED)
boot = acc_g[rng.integers(0, len(acc_g), (BOOTSTRAP_RESAMPLES, len(acc_g)))].mean(axis=1) * 100
b_lo, b_hi = np.percentile(boot, [2.5, 97.5])
say(f"  cluster bootstrap over gestures (95%) : {b_lo:.1f}-{b_hi:.1f}%")
say(f"  gestures at 100% : {(per_gesture.Accuracy == 100).sum()} of {len(per_gesture)}")
worst = per_gesture.loc[per_gesture.Accuracy == per_gesture.Accuracy.min(), "Gesture"].tolist()
say(f"  lowest accuracy  : {per_gesture.Accuracy.min():.1f}% ({', '.join(worst)})")
say(f"  gestures with errors : {(per_gesture.Correct < per_gesture.Trials).sum()}, total errors {n - k}")

fig, ax = plt.subplots(figsize=(10, 3.15), dpi=300)
x = np.arange(len(per_gesture))
acc, sd = per_gesture.Accuracy.to_numpy(), per_gesture.SD_rounds.to_numpy()
ax.bar(x, acc, width=0.72, color=BLUE, zorder=2, label="Per-gesture accuracy")
ax.errorbar(x, acc, yerr=[sd, np.minimum(sd, 100 - acc)], fmt="none", ecolor="#222",
            elinewidth=0.9, capsize=2.5, zorder=3, label="± SD across rounds")
ax.axhline(acc.mean(), color=RED, lw=1, ls="--", zorder=4, label=f"Overall mean ({acc.mean():.1f}%)")
ax.set_ylim(70, 100.5)
ax.set_xlim(-0.7, len(acc) - 0.3)
ax.set_xticks(x)
ax.set_xticklabels(per_gesture.Gesture, rotation=45, ha="right")
ax.set_ylabel("Recognition accuracy (%)")
ax.yaxis.grid(True, color="#ddd", lw=0.6, zorder=0)
ax.legend(loc="lower right", bbox_to_anchor=(1, 1.0), ncol=3, frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(OUT / "fig6_gesture_accuracy.png")
plt.close(fig)

# ------------------------------------------------------------------ speech-to-text
s = pd.read_csv(DATA / "speech_recognition.csv")
conds = [("Quiet", "Quiet\n(< 35 dB)"), ("Noisy", "Classroom-like noise\n(55–65 dB)")]
accs, sds, counts = [], [], []
say()
say("SPEECH-TO-TEXT (exact phrase match)")
for key, _ in conds:
    v = s.loc[s.TestType.str.contains(key)].sort_values("Trial")["Correct"].to_numpy()
    r = round_accuracies(v)
    lo, hi = wilson(int(v.sum()), len(v))
    accs.append(v.mean() * 100)
    sds.append(r.std(ddof=0))
    counts.append((int(v.sum()), len(v)))
    say(f"  {key:5s}: {v.mean() * 100:.1f}% ({int(v.sum())}/{len(v)}), population SD across rounds {r.std(ddof=0):.1f} pp, "
        f"Wilson 95% CI {lo:.1f}-{hi:.1f}%")
(kq, nq), (kn, nn) = counts
_, p_fisher = stats.fisher_exact([[kq, nq - kq], [kn, nn - kn]])
say(f"  accuracy difference {accs[0] - accs[1]:.1f} pp, Fisher's exact p = {p_fisher:.2f}")

labels = [c[1] for c in conds]
fig, ax = plt.subplots(figsize=(3.6, 2.4), dpi=300)
ax.bar([0, 1], accs, width=0.55, color=[BLUE, RED], zorder=2)
ax.errorbar([0, 1], accs, yerr=sds, fmt="none", ecolor="#222", elinewidth=0.9, capsize=3, zorder=3)
for i, a in enumerate(accs):
    ax.text(i, a + sds[i] + 0.6, f"{a:.1f}%", ha="center", fontsize=8)
ax.set_ylim(80, 100)
ax.set_xticks([0, 1])
ax.set_xticklabels(labels, fontsize=8)
ax.set_ylabel("Phrase-level accuracy (%)")
ax.yaxis.grid(True, color="#ddd", lw=0.6, zorder=0)
fig.tight_layout()
fig.savefig(OUT / "fig7_stt_accuracy.png")
plt.close(fig)

(OUT / "summary.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"\nResults written to {OUT}")
