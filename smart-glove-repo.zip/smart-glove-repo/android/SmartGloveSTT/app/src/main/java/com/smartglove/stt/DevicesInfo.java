package com.smartglove.stt;

/** Bluetooth address of the glove's HC-05 module: replace with the address of your module
 *  (Android Settings > Bluetooth > paired device details). */
public final class DevicesInfo {
    public static final String GLOVE_MAC_ADDRESS = "00:00:00:00:00:00";
    public static final TBluetooth BT_DEVICE = new TBluetooth(GLOVE_MAC_ADDRESS);

    private DevicesInfo() { }
}
