package com.smartglove.stt;

/*
 * Two-Way Smart Glove - speech-to-text companion app (English version).
 *
 * Speech is transcribed with Android's built-in speech recognizer
 * (android.speech.RecognizerIntent; on most phones provided by Google) and the
 * transcript is sent over classic Bluetooth (HC-05, SPP) to the glove, which
 * shows it on its 16x2 LCD. Messages are reduced to printable ASCII (the LCD
 * cannot display UTF-8) and terminated with '\n'.
 *
 * UI: CONNECT / DISCONNECT / LANGUAGE, a status line and a microphone button
 * that shows the last transcript (tap: speak, long press: send it again).
 */

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    /** Languages whose script the HD44780 LCD can show after ASCII reduction. */
    private static final String[] LANGUAGE_TAGS = {"en-US", "en-GB", "de-DE", "fr-FR", "es-ES", "hu-HU"};
    private static final String[] LANGUAGE_NAMES = {
            "English (US)", "English (UK)", "German", "French", "Spanish", "Hungarian"};
    private static final String PREFS = "settings";
    private static final String PREF_LANGUAGE = "language";

    private static final int REQUEST_SPEECH = 1;
    private static final int REQUEST_BT_PERMISSION = 2;

    private TextView status;
    private TextView transcriptView;
    private final ExecutorService btExecutor = Executors.newSingleThreadExecutor();
    private String language = "en-US";
    private String lastTranscript = "";
    private boolean connecting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        transcriptView = findViewById(R.id.transcript);
        View speak = findViewById(R.id.speak);
        Button connect = findViewById(R.id.connect);
        Button disconnect = findViewById(R.id.disconnect);
        Button languageButton = findViewById(R.id.language);

        language = prefs().getString(PREF_LANGUAGE, "en-US");

        speak.setOnClickListener(v -> startSpeechRecognition());
        speak.setOnLongClickListener(v -> {
            if (!lastTranscript.isEmpty()) {
                sendToGlove(lastTranscript);
                Toast.makeText(this, R.string.resent, Toast.LENGTH_SHORT).show();
            }
            return true;
        });
        connect.setOnClickListener(v -> connectToGlove());
        disconnect.setOnClickListener(v -> btExecutor.execute(DevicesInfo.BT_DEVICE::close));
        languageButton.setOnClickListener(v -> chooseLanguage());

        DevicesInfo.BT_DEVICE.setOnDisconnected(() -> runOnUiThread(this::refreshStatus));
        refreshStatus();
        requestBluetoothPermissionIfNeeded();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        DevicesInfo.BT_DEVICE.setOnDisconnected(null);
        btExecutor.execute(DevicesInfo.BT_DEVICE::close);
        btExecutor.shutdown();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    // ------------------------------------------------------------ language

    private void chooseLanguage() {
        int current = 0;
        for (int i = 0; i < LANGUAGE_TAGS.length; i++) if (LANGUAGE_TAGS[i].equals(language)) current = i;
        new AlertDialog.Builder(this)
                .setTitle(R.string.choose_language)
                .setSingleChoiceItems(LANGUAGE_NAMES, current, (dialog, which) -> {
                    language = LANGUAGE_TAGS[which];
                    prefs().edit().putString(PREF_LANGUAGE, language).apply();
                    refreshStatus();
                    dialog.dismiss();
                })
                .show();
    }

    // ------------------------------------------------------------ speech recognition

    private void startSpeechRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
        try {
            startActivityForResult(intent, REQUEST_SPEECH);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.stt_unavailable, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                lastTranscript = results.get(0);
                transcriptView.setText(lastTranscript);
                sendToGlove(lastTranscript);        // forwarded automatically
            }
        }
    }

    // ------------------------------------------------------------ Bluetooth

    private boolean hasBluetoothPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBluetoothPermissionIfNeeded() {
        if (!hasBluetoothPermission() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_BT_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BT_PERMISSION && !hasBluetoothPermission()) {
            Toast.makeText(this, R.string.bt_permission_needed, Toast.LENGTH_LONG).show();
        }
    }

    private void connectToGlove() {
        if (!hasBluetoothPermission()) {
            requestBluetoothPermissionIfNeeded();
            return;
        }
        if (connecting || DevicesInfo.BT_DEVICE.isConnected()) return;
        connecting = true;
        refreshStatus();
        btExecutor.execute(() -> {
            boolean ok = true;
            try {
                DevicesInfo.BT_DEVICE.connect();
            } catch (Exception e) {
                ok = false;
                DevicesInfo.BT_DEVICE.close();
            }
            final boolean connected = ok;
            runOnUiThread(() -> {
                connecting = false;
                refreshStatus();
                if (!connected) Toast.makeText(this, R.string.connect_failed, Toast.LENGTH_LONG).show();
            });
        });
    }

    /** Keeps printable ASCII only, because the HD44780 LCD cannot display UTF-8. */
    static String toLcdText(String s) {
        String plain = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD); // é -> e + accent
        return plain.trim().replaceAll("[^\\x20-\\x7E]", "");
    }

    private void sendToGlove(final String message) {
        final String lcdText = message == null ? "" : toLcdText(message);
        if (lcdText.isEmpty()) return;
        if (!DevicesInfo.BT_DEVICE.isConnected()) {
            Toast.makeText(this, R.string.not_connected_toast, Toast.LENGTH_SHORT).show();
            return;
        }
        btExecutor.execute(() -> {
            try {
                DevicesInfo.BT_DEVICE.write(lcdText + "\n");
            } catch (Exception e) {
                DevicesInfo.BT_DEVICE.close();
            }
        });
    }

    private void refreshStatus() {
        int state = connecting ? R.string.connecting
                : DevicesInfo.BT_DEVICE.isConnected() ? R.string.connected : R.string.not_connected;
        String shortLang = language.substring(0, 2);
        status.setText(getString(R.string.status_format, getString(state), shortLang));
    }
}
