package com.smartglove.stt;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** Minimal classic-Bluetooth (SPP) client for the HC-05 module on the glove. */
@SuppressLint("MissingPermission") // BLUETOOTH_CONNECT is checked in MainActivity before any call
public class TBluetooth {

    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private final String address;
    private final BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private OutputStream outStream;
    private Thread reader;
    private volatile boolean connected = false;
    private volatile Runnable onDisconnected;

    public TBluetooth(String address) {
        this.address = address.toUpperCase();
        this.adapter = BluetoothAdapter.getDefaultAdapter();
    }

    public boolean isConnected() {
        return connected;
    }

    /** Called (on a background thread) when an open connection is lost or closed. */
    public void setOnDisconnected(Runnable listener) {
        this.onDisconnected = listener;
    }

    public synchronized void connect() throws IOException {
        if (connected) return;
        if (adapter == null || !adapter.isEnabled()) throw new IOException("Bluetooth is off");
        if (!BluetoothAdapter.checkBluetoothAddress(address)) throw new IOException("Invalid address");
        BluetoothDevice device = adapter.getRemoteDevice(address);
        // No cancelDiscovery(): the app never starts discovery, and on Android 12+
        // that call would require the BLUETOOTH_SCAN permission.
        try {
            // RFCOMM channel 1 (works reliably with HC-05 modules)
            Method m = device.getClass().getMethod("createRfcommSocket", int.class);
            socket = (BluetoothSocket) m.invoke(device, 1);
            socket.connect();
        } catch (Exception reflectionOrConnectFailure) {
            closeQuietly();
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
            socket.connect();
        }
        outStream = socket.getOutputStream();
        connected = true;
        startReader(socket.getInputStream());
    }

    /** Detects a connection dropped by the glove: read() fails or returns -1. */
    private void startReader(final InputStream in) {
        reader = new Thread(() -> {
            byte[] buf = new byte[64];
            try {
                while (connected && in.read(buf) >= 0) { /* glove data is not used */ }
            } catch (IOException ignored) {
            }
            close();
        }, "glove-bt-reader");
        reader.setDaemon(true);
        reader.start();
    }

    public synchronized void write(String s) throws IOException {
        if (!connected) throw new IOException("Not connected");
        try {
            outStream.write(s.getBytes(StandardCharsets.US_ASCII));
            outStream.flush();
        } catch (IOException e) {
            close();
            throw e;
        }
    }

    public void close() {
        boolean wasConnected;
        synchronized (this) {
            wasConnected = connected;
            connected = false;
            closeQuietly();
        }
        Runnable l = onDisconnected;
        if (wasConnected && l != null) l.run();
    }

    private void closeQuietly() {
        if (outStream != null) {
            try { outStream.close(); } catch (IOException ignored) { }
            outStream = null;
        }
        if (socket != null) {
            try { socket.close(); } catch (IOException ignored) { }
            socket = null;
        }
    }
}
