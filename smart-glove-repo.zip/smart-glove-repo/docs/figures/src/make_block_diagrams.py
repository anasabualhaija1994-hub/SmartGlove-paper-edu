"""Redraw the block diagrams of the paper (Figures 2, 3 and 4) as high-resolution line art.

Usage:  python docs/figures/src/make_block_diagrams.py   (writes PNG at 600 dpi and PDF next to docs/figures)
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

OUT = Path(__file__).resolve().parent.parent
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
EDGE, FILL, CORE = "#222222", "white", "#EAF1F7"


def box(ax, x, y, w, h, text, fill=FILL, bold=False, fs=9):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0,rounding_size=0.12",
                                lw=1.0, ec=EDGE, fc=fill))
    ax.text(x, y, text, ha="center", va="center", fontsize=fs, weight="bold" if bold else "normal",
            linespacing=1.15)


def arrow(ax, pts, both=False, label=None, lpos=None, lha="center"):
    """Poly-line arrow through the points pts; arrow head at the last point."""
    for (x0, y0), (x1, y1) in zip(pts[:-2], pts[1:-1]):
        ax.plot([x0, x1], [y0, y1], color=EDGE, lw=1.0, solid_capstyle="butt")
    style = "<|-|>" if both else "-|>"
    ax.annotate("", xy=pts[-1], xytext=pts[-2],
                arrowprops=dict(arrowstyle=style, color=EDGE, lw=1.0, shrinkA=0, shrinkB=0, mutation_scale=9))
    if label:
        ax.text(*lpos, label, ha=lha, va="center", fontsize=7.5, style="italic", color="#333")


def canvas(w, h):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, w)
    ax.set_ylim(0, h)
    ax.set_aspect("equal")
    ax.axis("off")
    fig.subplots_adjust(0, 0, 1, 1)
    return fig, ax


def save(fig, name):
    fig.savefig(OUT / f"{name}.png", dpi=600)
    fig.savefig(OUT / f"{name}.pdf")
    plt.close(fig)


# ---------------------------------------------------------------- Figure 2: gesture-to-speech
TOP, BOT, bh = 1.95, 0.5, 0.62
fig, ax = canvas(6.4, 2.45)
box(ax, 0.75, TOP, 1.25, bh, "Hand gesture\n(user)", fill=CORE)
box(ax, 3.0, TOP, 1.55, bh, "Flex sensors (×5)\n+ accelerometer")
box(ax, 5.4, TOP, 1.6, bh, "Arduino Pro Mini\ntemplate matching")
box(ax, 5.4, BOT, 1.6, bh, "DFPlayer Mini\n(SD card audio)")
box(ax, 3.0, BOT, 1.55, bh, "Speaker")
box(ax, 0.75, BOT, 1.25, bh, "Spoken word\n(listener)", fill=CORE)
arrow(ax, [(1.375, TOP), (2.225, TOP)])
arrow(ax, [(3.775, TOP), (4.6, TOP)], label="analog / I²C", lpos=(4.19, TOP + 0.13))
arrow(ax, [(5.4, TOP - bh / 2), (5.4, BOT + bh / 2)], label="track number", lpos=(5.5, (TOP + BOT) / 2), lha="left")
arrow(ax, [(4.6, BOT), (3.775, BOT)])
arrow(ax, [(2.225, BOT), (1.375, BOT)])
save(fig, "fig2_gesture_dataflow")

# ---------------------------------------------------------------- Figure 3: speech-to-text
fig, ax = canvas(6.4, 2.45)
box(ax, 0.75, TOP, 1.25, bh, "Speech\n(speaker)", fill=CORE)
box(ax, 3.0, TOP, 1.55, bh, "Smartphone app\n(speech recognition)")
box(ax, 5.4, TOP, 1.6, bh, "Arduino Pro Mini")
box(ax, 5.4, BOT, 1.6, bh, "Vibration motor + LED\n(1 s alert)")
box(ax, 3.0, BOT, 1.55, bh, "16×2 LCD\n(text shown 3 s)")
box(ax, 0.75, BOT, 1.25, bh, "Text\n(wearer)", fill=CORE)
arrow(ax, [(1.375, TOP), (2.225, TOP)])
arrow(ax, [(3.775, TOP), (4.6, TOP)], label="Bluetooth", lpos=(4.19, TOP + 0.13))
arrow(ax, [(5.7, TOP - bh / 2), (5.7, BOT + bh / 2)], label="1. alert", lpos=(5.8, (TOP + BOT) / 2), lha="left")
arrow(ax, [(4.9, TOP - bh / 2), (4.9, 1.22), (3.0, 1.22), (3.0, BOT + bh / 2)], label="2. text (I²C)", lpos=(3.1, 1.02), lha="left")
arrow(ax, [(2.225, BOT), (1.375, BOT)])
save(fig, "fig3_stt_workflow")

# ---------------------------------------------------------------- Figure 4: hardware block diagram
fig, ax = canvas(6.4, 3.2)
box(ax, 3.0, 1.75, 1.5, 1.9, "Arduino\nPro Mini\n(ATmega328P,\n3.3 V, 8 MHz)", fill=CORE, bold=True)
box(ax, 0.8, 2.55, 1.4, 0.5, "MPU-6050\naccelerometer", fs=8.5)
box(ax, 0.8, 1.75, 1.4, 0.5, "Flex sensors (×5)", fs=8.5)
box(ax, 0.8, 0.95, 1.4, 0.5, "9 V battery", fs=8.5)
box(ax, 5.35, 2.55, 1.45, 0.5, "HC-05 Bluetooth", fs=8.5)
box(ax, 5.35, 1.75, 1.45, 0.5, "DFPlayer Mini\n→ speaker", fs=8.5)
box(ax, 5.35, 0.95, 1.45, 0.5, "I²C backpack\n→ 16×2 LCD", fs=8.5)
box(ax, 3.0, 0.3, 2.3, 0.42, "Vibration motor + LED (D8)", fs=8.5)
arrow(ax, [(1.5, 2.55), (2.25, 2.55)], both=True, label="I²C", lpos=(1.875, 2.72))
arrow(ax, [(1.5, 1.75), (2.25, 1.75)], label="ADC", lpos=(1.875, 1.92))
arrow(ax, [(1.5, 0.95), (2.25, 0.95)], label="power", lpos=(1.875, 1.12))
arrow(ax, [(3.75, 2.55), (4.625, 2.55)], both=True, label="UART 9600", lpos=(4.19, 2.72))
arrow(ax, [(3.75, 1.75), (4.625, 1.75)], label="SW serial", lpos=(4.19, 1.92))
arrow(ax, [(3.75, 0.95), (4.625, 0.95)], label="I²C", lpos=(4.19, 1.12))
arrow(ax, [(3.0, 0.8), (3.0, 0.51)])
save(fig, "fig4_block_diagram")
print("written to", OUT)
