/*
 * Two-Way Smart Glove - gesture calibration sketch
 *
 * Records the min/max template of ONE gesture and prints it as a row that can
 * be pasted into TEMPLATES[] in firmware/gesture_to_speech/gesture_to_speech.ino.
 *
 * Procedure (per gesture):
 *   1. Upload, open the Serial Monitor at 57600 baud (enable "Show timestamp"
 *      to obtain the output format of Figure 1 of the paper).
 *   2. Form the gesture whenever "Move Now" appears and hold it during the
 *      capture window; relax between windows (10 windows in total).
 *   3. Copy the printed template row and set the audio-track number (last column).
 *   4. Press RESET to calibrate the next gesture.
 *
 * Each window takes 1000 consecutive readings of each of the 8 channels,
 * acquired channel by channel (f1-f5 = flex sensors as raw 10-bit values,
 * x/y/z = accelerometer axes mapped to nominally 0-255), and prints the
 * minimum and maximum of every channel. The stored window interval is
 * [min - MARGIN, max + MARGIN]; the template is the union of the 10 windows.
 */

#include <Wire.h>
#include <MPU6050.h>

const uint8_t  FLEX_PINS[5] = {A0, A1, A2, A3, A6};
const uint8_t  N_WINDOWS    = 10;
const uint16_t N_READINGS   = 1000;
const int      MARGIN       = 10;
const uint16_t START_DELAY_MS  = 5000;
const uint16_t WINDOW_DELAY_MS = 5000;

MPU6050 mpu;
int16_t windows[N_WINDOWS][16];   // [max + MARGIN, min - MARGIN] x 8 channels
const char *const CH_NAMES[8] = {"f1", "f2", "f3", "f4", "f5", "x", "y", "z"};

int16_t readChannel(uint8_t ch) {
  if (ch < 5) return analogRead(FLEX_PINS[ch]);
  int16_t ax, ay, az;
  mpu.getAcceleration(&ax, &ay, &az);
  int16_t v = (ch == 5) ? ax : (ch == 6) ? ay : az;
  return map(v, -17000, 17000, 0, 255);
}

void setup() {
  Serial.begin(57600);                 // 115200 is unreliable on an 8 MHz Pro Mini
  Wire.begin();
  mpu.initialize();

  for (uint8_t w = 0; w < N_WINDOWS; w++) {
    delay(w == 0 ? START_DELAY_MS : WINDOW_DELAY_MS);   // time to (re)form the gesture
    Serial.println(F("Move Now"));
    for (uint8_t ch = 0; ch < 8; ch++) {
      int16_t mx = readChannel(ch), mn = mx;
      for (uint16_t r = 0; r < N_READINGS; r++) {
        int16_t v = readChannel(ch);
        if (v > mx) mx = v;
        if (v < mn) mn = v;
      }
      windows[w][2 * ch]     = mx + MARGIN;
      windows[w][2 * ch + 1] = mn - MARGIN;
    }
    // one line per window: max f1=.. //min f1=.. // ... //max z=.. //min z=..
    for (uint8_t ch = 0; ch < 8; ch++) {
      if (ch > 0) Serial.print(F(" //"));
      Serial.print(F("max ")); Serial.print(CH_NAMES[ch]); Serial.print('=');
      Serial.print(windows[w][2 * ch] - MARGIN);
      Serial.print(F(" //min ")); Serial.print(CH_NAMES[ch]); Serial.print('=');
      Serial.print(windows[w][2 * ch + 1] + MARGIN);
    }
    Serial.println();
  }

  // union of all windows
  int16_t tpl[16];
  for (uint8_t j = 0; j < 16; j += 2) {
    tpl[j] = windows[0][j];
    tpl[j + 1] = windows[0][j + 1];
    for (uint8_t w = 1; w < N_WINDOWS; w++) {
      if (windows[w][j] > tpl[j])         tpl[j] = windows[w][j];
      if (windows[w][j + 1] < tpl[j + 1]) tpl[j + 1] = windows[w][j + 1];
    }
  }

  Serial.println(F("Template row (set the last value to the audio track):"));
  Serial.print(F("  {"));
  for (uint8_t j = 0; j < 16; j++) { Serial.print(tpl[j]); Serial.print(F(", ")); }
  Serial.println(F("TRACK},"));
}

void loop() {}
