/*
 * Two-Way Smart Glove - main firmware (gesture-to-speech + speech-to-text)
 *
 * R. Altamimi and A. Abu Alhaija'a, "Interactive Learning through Assistive
 * Technology: A Two-Way Smart Glove for Students with Communication Impairments".
 *
 * Board : Arduino Pro Mini (ATmega328P, 3.3 V, 8 MHz)
 * Parts : 5 flex sensors (A0, A1, A2, A3, A6), MPU-6050 (I2C: A4/A5),
 *         16x2 LCD with I2C backpack (I2C: A4/A5), HC-05 Bluetooth module
 *         (hardware serial, 9600 baud), DFPlayer Mini (software serial:
 *         D10 = Arduino RX <- DFPlayer TX, D11 = Arduino TX -> DFPlayer RX),
 *         vibration motor (via driver transistor) + LED, both on D8.
 * Libs  : hd44780 (Bill Perry), DFRobotDFPlayerMini, MPU6050 (I2Cdevlib / Electronic Cats)
 *
 * Gesture-to-speech: every loop the 8 live channel values (5 flex readings as
 * raw 10-bit ADC values, 3 accelerometer axes mapped from +/-17000 counts to
 * nominally 0-255; values beyond ~1 g are not clipped) are compared with the calibrated min/max template of each gesture
 * (+/-10 run-time tolerance). The first template that matches on all 8
 * channels triggers a 200 ms vibration/LED cue and plays its audio track
 * (SD card: /mp3/0001.mp3 ...). A 2 s hold-off follows; while a gesture is
 * held, its audio is repeated roughly every 2.2 s.
 *
 * Speech-to-text: text received from the Android app over Bluetooth triggers a
 * 1 s vibration/LED alert and is then shown on the LCD (max. 2 x 16 characters)
 * for 3 s. Only printable ASCII characters are kept (the app terminates each
 * message with '\n'; line breaks are ignored).
 *
 * Templates are produced with firmware/calibration/calibration.ino.
 */

#include <Wire.h>
#include <MPU6050.h>
#include <SoftwareSerial.h>
#include <DFRobotDFPlayerMini.h>
#include <hd44780.h>
#include <hd44780ioClass/hd44780_I2Cexp.h>
#include <avr/pgmspace.h>

// ---------------------------------------------------------------- pins
const uint8_t PIN_ALERT = 8;               // vibration motor + LED
const uint8_t FLEX_PINS[5] = {A0, A1, A2, A3, A6};

// ---------------------------------------------------------------- timing / tolerances
const int      TOLERANCE          = 10;    // run-time tolerance on each template bound
const uint16_t GESTURE_CUE_MS     = 200;   // cue before playing a gesture
const uint16_t GESTURE_HOLDOFF_MS = 2000;  // limits repeated triggering
const uint16_t MSG_ALERT_MS       = 1000;  // alert when a message arrives
const uint16_t MSG_DISPLAY_MS     = 3000;  // time a message stays on the LCD
const uint8_t  LCD_COLS = 16, LCD_ROWS = 2;

// ---------------------------------------------------------------- devices
hd44780_I2Cexp       lcd;
SoftwareSerial       mp3Serial(10, 11);    // Arduino RX (<- DFPlayer TX), Arduino TX (-> DFPlayer RX)
DFRobotDFPlayerMini  player;
MPU6050              mpu;

// ---------------------------------------------------------------- gesture templates
// Column order per row: flex1 max, flex1 min, ... flex5 max, flex5 min,
//                       ax max, ax min, ay max, ay min, az max, az min, audio track
// Row order = GestureID in data/ (the 30-word study vocabulary).
// Templates are scanned in this order and the first full match is accepted.
const uint8_t N_GESTURES = 30;
const uint8_t N_BOUNDS   = 16;
const int16_t TEMPLATES[N_GESTURES][N_BOUNDS + 1] PROGMEM = {
  { 197,  166,  405,  372,  364,  331,  291,  259,  279,  246,  123,   51,   48,    1,  205,  132,   4},  //  1 She
  { 173,  123,  232,  175,  331,  277,  333,  282,  153,  110,  154,   45,  237,  164,  232,  169,   1},  //  2 I
  { 204,  142,  226,  161,  367,  324,  330,  294,  161,  115,  140,   38,   93,    6,  236,  129,   2},  //  3 You
  { 208,  166,  396,  365,  369,  331,  332,  289,  183,  118,  147,  -78,   50,    4,  185,  152,   3},  //  4 He
  { 369,  283,  411,  341,  361,  325,  268,  225,  297,  267,  144,   47,   58,    7,  218,  156,   5},  //  5 It
  { 180,  135,  232,  195,  346,  305,  328,  289,  148,  112,   30,   -6,  173,   97,  166,   79,  11},  //  6 Am
  { 330,  263,  410,  354,  238,  194,  361,  320,  308,  265,  143,   43,   53,   -3,  214,  119,  10},  //  7 Are
  { 371,  275,  421,  327,  369,  336,  256,  218,  313,  282,  238,  186,  115,   49,  224,  158,   8},  //  8 Thank
  { 335,  290,  416,  376,  360,  317,  282,  230,  324,  270,  153,   59,  207,   98,  243,  196,   9},  //  9 Hungry
  { 303,  256,  404,  366,  241,  192,  354,  312,  287,  249,  257,  188,  106,   28,  202,  110,   7},  // 10 Good
  { 315,  269,  346,  273,  289,  222,  351,  313,  334,  275,  246,  173,  249,  177,  127,   29,  13},  // 11 Morning
  { 320,  267,  406,  369,  350,  301,  326,  293,  327,  288,  215,  130,   91,  -10,  122,   -1,  12},  // 12 Night
  { 208,  171,  399,  368,  377,  345,  335,  306,  160,  131,  175,   99,  197,   93,  245,  205,  17},  // 13 Go
  { 354,  279,  408,  329,  220,  184,  348,  305,  264,  228,  241,  172,  252,  189,  141,   83,  18},  // 14 The
  { 195,  156,  400,  363,  364,  319,  323,  261,  161,  120,   31,   -6,  184,  112,  123,   80,  21},  // 15 Do
  { 282,  239,  329,  260,  280,  233,  343,  305,  294,  263,  137,   24,   66,   -3,  213,  103,  22},  // 16 Is
  { 233,  170,  267,  202,  331,  300,  313,  277,  277,  247,  115,   42,   62,   18,  209,  150,  29},  // 17 Want
  { 223,  170,  321,  253,  257,  200,  339,  288,  200,  136,  252,  146,  243,  164,  112,   34,  54},  // 18 Need
  { 227,  186,  329,  288,  230,  188,  311,  268,  173,  138,  166,   34,   94,   26,  229,  173,  30},  // 19 Market
  { 189,  157,  242,  201,  352,  318,  336,  301,  187,  151,  236,  178,  225,  159,  116,   20,  31},  // 20 Where
  { 217,  183,  396,  366,  362,  334,  332,  301,  195,  161,  233,  169,  233,  168,  111,   34,  32},  // 21 How
  { 200,  165,  268,  233,  335,  297,  257,  209,  281,  239,  261,  207,  106,   31,  158,   88,  35},  // 22 Hi
  { 213,  164,  284,  245,  346,  312,  270,  218,  315,  230,  164,   62,  190,  137,  240,  202,  38},  // 23 Home
  { 366,  296,  380,  308,  360,  303,  325,  272,  287,  250,  120,   57,   68,   13,   72,   12,  34},  // 24 Careful
  { 237,  178,  345,  239,  226,  175,  231,  184,  274,  239,  262,  230,  119,   61,  127,   64,  37},  // 25 Yes
  { 219,  185,  346,  252,  230,  190,  330,  290,  296,  265,  257,  193,   95,   15,  138,   84,  36},  // 26 No
  { 170,  133,  227,  195,  355,  320,  318,  285,  170,  136,  258,  224,   93,   47,  147,   92,  55},  // 27 Teacher
  { 248,  177,  286,  221,  349,  313,  328,  297,  304,  266,  257,  220,   97,   41,  147,  100,  56},  // 28 Student
  { 230,  153,  267,  198,  346,  301,  329,  289,  262,  229,  227,  161,  229,  154,   90,    3,  57},  // 29 School
  { 167,  136,  236,  201,  203,  150,  322,  291,  153,  123,  219,  164,   42,   -2,  134,   73,  16},  // 30 Thirsty
};

String voice;

// ---------------------------------------------------------------- helpers
static inline int16_t tplValue(uint8_t row, uint8_t col) {
  return (int16_t)pgm_read_word(&TEMPLATES[row][col]);
}

void pulseAlert(uint16_t ms) {
  digitalWrite(PIN_ALERT, HIGH);
  delay(ms);
  digitalWrite(PIN_ALERT, LOW);
}

void showMessage(const String &msg) {
  lcd.clear();
  pulseAlert(MSG_ALERT_MS);
  lcd.setCursor(0, 0);
  for (uint8_t i = 0; i < LCD_COLS && i < msg.length(); i++) lcd.print(msg[i]);
  if (msg.length() > LCD_COLS) {
    lcd.setCursor(0, 1);
    for (uint8_t i = LCD_COLS; i < LCD_COLS * LCD_ROWS && i < msg.length(); i++) lcd.print(msg[i]);
  }
  delay(MSG_DISPLAY_MS);
  lcd.clear();
}

// ---------------------------------------------------------------- setup / loop
void setup() {
  mp3Serial.begin(9600);
  player.begin(mp3Serial);

  Serial.begin(9600);                      // HC-05 Bluetooth module
  Wire.begin();
  mpu.initialize();

  lcd.begin(LCD_COLS, LCD_ROWS);
  pinMode(PIN_ALERT, OUTPUT);
  voice.reserve(64);
}

void loop() {
  // ---------- speech-to-text: collect text sent by the smartphone ----------
  while (Serial.available()) {
    delay(10);                             // let the rest of the message arrive
    char c = Serial.read();
    if (c >= 32 && c < 127 && voice.length() < LCD_COLS * LCD_ROWS) voice += c;  // printable ASCII only
  }
  if (voice.length() > 0) showMessage(voice);
  voice = "";

  // ---------- gesture-to-speech: read sensors ----------
  int16_t live[8];
  for (uint8_t f = 0; f < 5; f++) live[f] = analogRead(FLEX_PINS[f]);

  int16_t ax, ay, az;
  mpu.getAcceleration(&ax, &ay, &az);
  live[5] = map(ax, -17000, 17000, 0, 255);
  live[6] = map(ay, -17000, 17000, 0, 255);
  live[7] = map(az, -17000, 17000, 0, 255);

  // ---------- template matching (first full match wins) ----------
  for (uint8_t g = 0; g < N_GESTURES; g++) {
    uint8_t k = 0;
    for (; k < 8; k++) {
      int16_t hi = tplValue(g, 2 * k)     + TOLERANCE;
      int16_t lo = tplValue(g, 2 * k + 1) - TOLERANCE;
      if (live[k] > hi || live[k] < lo) break;
    }
    if (k == 8) {
      pulseAlert(GESTURE_CUE_MS);
      player.playMp3Folder(tplValue(g, N_BOUNDS));   // plays /mp3/NNNN.mp3
      delay(GESTURE_HOLDOFF_MS);
      break;
    }
  }
}
